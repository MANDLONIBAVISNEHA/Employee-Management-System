package com.employee.user.service.dto;

import lombok.Data;

@Data
public class Department {

	private int id;

	private String name;

	private String description;

	private int status;

}
