package com.employee.user.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
