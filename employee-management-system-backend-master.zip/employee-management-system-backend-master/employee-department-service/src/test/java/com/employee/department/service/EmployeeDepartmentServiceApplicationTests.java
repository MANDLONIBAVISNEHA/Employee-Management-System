package com.employee.department.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDepartmentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
