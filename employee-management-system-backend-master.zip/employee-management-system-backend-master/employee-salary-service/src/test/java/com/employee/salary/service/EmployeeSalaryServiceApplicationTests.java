package com.employee.salary.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeSalaryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
